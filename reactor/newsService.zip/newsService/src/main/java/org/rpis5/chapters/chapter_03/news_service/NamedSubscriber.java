package org.rpis5.chapters.chapter_03.news_service;

public interface NamedSubscriber {
    String getName();
}
